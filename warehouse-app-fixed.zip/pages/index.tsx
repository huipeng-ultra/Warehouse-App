import { useState, useEffect } from 'react'
import { createClient } from '@supabase/supabase-js'

// 🔑 Supabase 客户端
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

export default function Home() {
  const [session, setSession] = useState(null)
  const [email, setEmail] = useState('')

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
    })
    
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setSession(session)
      }
    )
    
    return () => subscription.unsubscribe()
  }, [])

  const handleLogin = async (e: any) => {
    e.preventDefault()
    await supabase.auth.signInWithOtp({ email })
    alert('请查收邮箱中的登录链接！')
  }

  if (!session) {
    return (
      <div className=\"flex h-screen items-center justify-center bg-gray-100\">
        <form onSubmit={handleLogin} className=\"bg-white p-8 rounded-2xl shadow-md w-96\">
          <h1 className=\"text-2xl font-bold mb-4 text-center\">海外仓登录</h1>
          <input
            type=\"email\"
            placeholder=\"请输入邮箱\"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className=\"border p-2 w-full rounded mb-4\"/>
          <button className=\"bg-blue-600 text-white px-4 py-2 rounded w-full\">登录 / 注册</button>
        </form>
      </div>
    )
  }

  return (
    <div className=\"p-6\">
      <h1 className=\"text-2xl font-bold mb-4\">📦 海外仓 Dashboard</h1>
      <p>欢迎，{session.user.email}</p>
      <button
        className=\"mt-4 bg-red-500 text-white px-4 py-2 rounded\"
        onClick={() => supabase.auth.signOut()}
      >
        退出登录
      </button>
    </div>
  )
}
